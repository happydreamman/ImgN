# D-A-L-L-E-Image-Generator
A simple gui app made with python and OpenAi's API to try out D A L L E 2 module.

# install library
pip install -r requirements.txt

# run gui
python gui.py
